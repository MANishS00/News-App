import 'package:flutter/material.dart';

var klogo = Image.asset('assets/logo/logo.png');
